#include "paaikkuna.h"
#include "ui_paaikkuna.h"
#include "connection.h"


PaaIkkuna::PaaIkkuna(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PaaIkkuna)
{
    ui->setupUi(this);
}

PaaIkkuna::~PaaIkkuna()
{
    delete ui;
}

void PaaIkkuna::on_pushButtonNosto_clicked()
{

}

void PaaIkkuna::on_pushButtonKate_clicked()
{

}

void PaaIkkuna::on_pushButtonLasku_clicked()
{

}

void PaaIkkuna::on_pushButtonSiirto_clicked()
{

}

void PaaIkkuna::on_pushButtonTiliTapahtumat_clicked()
{

}

void PaaIkkuna::on_pushButtonKirjauduUlos_clicked()
{

}
