#ifndef PAAIKKUNA_H
#define PAAIKKUNA_H

#include <QMainWindow>
#include <QApplication>
#include <QWidget>
#include <QtWidgets>
#include <QtSql>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlQueryModel>

#include "connection.h"


namespace Ui {
class PaaIkkuna;
}

class PaaIkkuna : public QMainWindow
{
    Q_OBJECT

public:
    explicit PaaIkkuna(QWidget *parent = nullptr);
    ~PaaIkkuna();

private slots:
    void on_pushButtonNosto_clicked();

    void on_pushButtonKate_clicked();

    void on_pushButtonLasku_clicked();

    void on_pushButtonSiirto_clicked();

    void on_pushButtonTiliTapahtumat_clicked();

    void on_pushButtonKirjauduUlos_clicked();

private:
    Ui::PaaIkkuna *ui;
};

#endif // PAAIKKUNA_H
